/* do not edit! See version */ 
#define FRIP_VER_STR "Version 44" 
#define FRIP_VER_NUM 44 
