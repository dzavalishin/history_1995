#include "msgid.h"

#include "fstream.h"
//#include "stdstream.h"

void test( char *inf)
    {
    msgid_base b( "msgid.dat" );
    
    
    ifstream is( inf );
    ofstream os( "data.out" );
    
    if( !is || !os )
        throw Ex_Fail( "test", "open error", "" );

    while( 1 )
        {
        char line[1024];

        is.getline( line, 1024 );

        if(is.eof()) break;
        
        if( b.check( string(line) ) )
            os << " '" << line << "' is dupe\n";
        //else
        //    os << " '" << line << "' is new\n";
        }

    b.flush();
    
    }


int main( int ac, char **av )
    {

    try { test(av[1]); }
    catch( General_Ex ex )
        {
        ex.print();
        }

    return 0;
    }
    

void General_Ex::print() const
    {
    cerr
        << where.c_str() << ": " << what.c_str()
        << " (" << why.c_str() << ")\n";
    }



