
#include "msgid.h"

#include <ctype.h>



const crc32poly =  0xEDB88320L;  // Generator polynomial number
const crc32init =  0xFFFFFFFFL;  // Initial CRC value for calculation
const crc32test =  0xDEBB20E3L;  // Result to test for at receiver

//#define h_crc32test(crc)   (((crc) == CRC32TEST) ? 1 : 0)

class crc32table
    {
    char t[256];
    public:
        crc32table();
        const char *tab() { return t; }
    };

static crc32table  crc32tab;

crc32table::crc32table()
    {
    int   i, j, crc;

    for (i = 0; i <= 255; i++) 
        {
        crc = i;
        for (j = 8; j > 0; j--) 
            {
            if (crc & 1) crc = (crc >> 1) ^ crc32poly;
            else         crc >>= 1;
            }
        t[i] = crc;
        }
    }

inline int crc32upd(const char *crctab, int crc, char c)
    {
    return ((crctab)[((int) (crc) ^ (c)) & 0xff] ^ ((crc) >> 8));
    }

long crc32( const char *data, int len )
    {
    int crc = crc32init;
    //MP_Dump("counting crc for", data, len );
    while (len--) crc = crc32upd(crc32tab.tab(),crc,*data++);

    //MP_Message("counted crc = 0x%x", ~crc );
    return ~crc;
    }
        




