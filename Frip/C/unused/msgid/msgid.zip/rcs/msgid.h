head	1.2;
access;
symbols;
locks;
comment	@ * @;


1.2
date	96.08.12.17.08.26;	author dz;	state Exp;
branches;
next	1.1;

1.1
date	96.08.09.16.13.48;	author dz;	state Exp;
branches;
next	;


desc
@@


1.2
log
@*** empty log message ***
@
text
@/*\
 *        The software included, file formats and basic algorithms are
 *      copyright (C) 1995,96 by Dmitry Zavalishin. All rights reserved.
 *
 *	Module: msgid base
 *
 *      $Log: frip.C $
 *
\*/

#include <strng.h>
#include <except.h>
#include <binbuf.h>

#include <fstream.h>
#include <stddef.h>

  // Limitations:
  // - MSGID length should not be > 64 bytes.


const DEF_PAGESIZE   = 512;
const DEF_PAGES      = (100*1024)/DEF_PAGESIZE;

class msgid : public string
    {
    public:
        int hashvalue(int modulo) const;

        msgid( const msgid& m ) : string( (string&)m ) {}
        msgid( const string& m ) : string( m ) {}
    };

class msgid_base
    {
    fstream      pf;
    string       pfn;
    bool         is_open;

    char         *buf;
    int          cur_page;
    bool         cur_page_modified;

    static const char signature[10];
    
    struct header
        {
        header()   { memset( this, 0, sizeof(header) );  }

        void read(fstream &) const;
        void write(fstream &);
        
        char  signature[10];

        int   version;
        
        int   page_size;
        int   pages;

        char  reserved[ 512 - (((sizeof(int))*3)+10) - 4];
        };

    header h;
    
    void rebuild( int &pagesize, int &pages );
    //bool exist();
    void open();
    void close();

    int  page_pos( int p );
    void read_page( int );
    void write_page( int );

    void flush_cur_page();
    void set_cur_page( int );

    bool check_in_buf( const msgid &id, bool add );
    
    public:
        msgid_base( string fn, int pagesize = -1, int pages = -1 )
            {
            is_open = No;
            cur_page = -1;
            cur_page_modified = No;
            buf = NULL;
            pfn = fn;
            
            if( sizeof(header) != 512 )
                throw Ex_Errno( "msgid_base::msgid_base", "sizeof(header) != 512", sizeof(header) );

            try
                {
                  // theoretically close is called from open and
                  // is able to throw something too, but souldn't
                  // in this case 'cause it does nothing if file
                  // is not really open yet.
                open(); 
                if(
                   (h.page_size != pagesize && pagesize != -1 ) ||
                   (h.pages != pages && pages != -1)
                  )
                    throw Ex_Arg("msgid_base::msgid_base", "PageFile will be rebuilt", fn );
                }
            catch( General_Ex ex )
                {
                ex.print();

                if( pagesize == -1 ) pagesize = DEF_PAGESIZE;
                if( pages    == -1 ) pages    = DEF_PAGES;
                
                rebuild( pagesize, pages );
                open();
                }
            }

        ~msgid_base() { close(); }

        bool is_dupe( const msgid &data ); // yes = dupe.
        bool check( const msgid &data ); // yes = dupe. msgid goes to base anyway

        void flush() { flush_cur_page(); pf.flush(); }
    };





@


1.1
log
@Initial revision
@
text
@d11 6
a16 2
#include "strng.h"
#include "binbuf.h"
d22 2
d25 1
a25 2

class msgid ; public string
d29 3
d43 1
a43 1
    
d60 1
a60 1
        char  reserved[ 512 - offsetof(reserved) ];
d66 1
a66 1
    bool exist();
d70 1
d77 1
a77 1
    bool check_in_buf( const msgid & ) const;
d80 1
a80 1
        msgid_base( string fn, int pagesize, int pages ) 
d86 4
d98 4
a101 1
                if( h.pagesize != pagesize || h.pages != pages )
d108 3
d120 2
@
