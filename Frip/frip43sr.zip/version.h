/* do not edit! See version */ 
#define FRIP_VER_STR "Version 43" 
#define FRIP_VER_NUM 43 
