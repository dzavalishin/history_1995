head	1.10;
access;
symbols;
locks;
comment	@ * @;


1.10
date	97.03.17.08.03.42;	author dz;	state Exp;
branches;
next	1.9;

1.9
date	97.03.05.18.12.38;	author dz;	state Exp;
branches;
next	1.8;

1.8
date	97.01.21.08.53.51;	author dz;	state Exp;
branches;
next	1.7;

1.7
date	97.01.02.10.06.18;	author dz;	state Exp;
branches;
next	1.6;

1.6
date	97.01.01.16.08.42;	author dz;	state Exp;
branches;
next	1.5;

1.5
date	96.12.28.13.42.00;	author dz;	state Exp;
branches;
next	1.4;

1.4
date	96.09.08.19.05.31;	author dz;	state Exp;
branches;
next	1.3;

1.3
date	96.08.04.17.28.17;	author dz;	state Exp;
branches;
next	1.2;

1.2
date	96.08.04.08.18.43;	author dz;	state Exp;
branches;
next	1.1;

1.1
date	96.07.31.07.00.23;	author dz;	state Exp;
branches;
next	;


desc
@@


1.10
log
@*** empty log message ***
@
text
@/* do not edit! */ 
#define FRIP_VER_STR "Version 37" 
#define FRIP_VER_NUM 37 
@


1.9
log
@Ver. 34
@
text
@d2 2
a3 2
#define FRIP_VER_STR "Version 35" 
#define FRIP_VER_NUM 35 
@


1.8
log
@*** empty log message ***
@
text
@d2 2
a3 2
#define FRIP_VER_STR "Version 31" 
#define FRIP_VER_NUM 31 
@


1.7
log
@*** empty log message ***
@
text
@d2 2
a3 2
#define FRIP_VER_STR "Version 29" 
#define FRIP_VER_NUM 29 
@


1.6
log
@Before changing
@
text
@d2 2
a3 2
#define FRIP_VER_STR "Version 28" 
#define FRIP_VER_NUM 28 
@


1.5
log
@Ver. 27
@
text
@d2 2
a3 2
#define FRIP_VER_STR "Version 27" 
#define FRIP_VER_NUM 27 
@


1.4
log
@Version 25
@
text
@d1 3
a3 3
/* do not edit! */
#define FRIP_VER_STR "Version 25"
#define FRIP_VER_NUM 25
@


1.3
log
@Exceptions added, not compiled
@
text
@d2 2
a3 2
#define FRIP_VER_STR "Version 23"
#define FRIP_VER_NUM 23
@


1.2
log
@Before exceptions.
@
text
@@


1.1
log
@Initial revision
@
text
@d2 2
a3 2
#define FRIP_VER_STR "Version 20"
#define FRIP_VER_NUM 20
@
