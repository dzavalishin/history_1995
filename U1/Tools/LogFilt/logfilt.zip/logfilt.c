#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int
main( int ac, char **av )
	{

	if( ac != 3 )
		{
		printf("Usage: LogFilter UU2-Log-File Out-File\n");
		exit(33);
		}

	FILE *ifp, *ofp;

	ifp = fopen( av[1], "rt" );
	if( ifp == NULL )
		{
		printf("Error: Can't open %s\n", av[1] );
		exit(33);
		}

	ofp = fopen( av[2], "wt" );
	if( ofp == NULL )
		{
		printf("Error: Can't create %s\n", av[2] );
		exit(33);
		}

	setvbuf( ifp, NULL, _IOFBF, 16*1024 );
	setvbuf( ofp, NULL, _IOFBF, 16*1024 );

	while( !feof( ifp ) )
		{
		const   bs = 200;
		char	buf[bs];

		if( fgets( buf, bs, ifp ) == NULL )
			break;

		char *cp = strpbrk( buf, "\r\n" );
		if( *cp ) *cp = '\0';

		int pos = 0;
		int  d = 0; // Dummy
		if( 1 != sscanf( buf, "$ %*d:%*d:%*d %n\"%*[^\"]\", \"%*[^\"]\", \"%*[^\"]\", \"%*[^\"]\", %d",
			   &pos, &d ))
			continue;

		cp = buf + pos;

		fprintf( ofp, "%s\n", cp );
		}

	if( ferror( ifp ) )
		{
		printf( "Error reading input file\n" );
		exit(33);
		}


	if( ferror( ofp ) )
		{
		printf( "Error writing output file\n" );
		exit(33);
		}


	return 0;
	}



