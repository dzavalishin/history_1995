/************************ Mali mover ***************************\
 *
 *      Copyright (C) 1991-1993 by Infinity Soft
 *
 *      Module  :	Main conversion loop
 *
 *      $Log: MainLoop.c $
 * Revision 1.1  1994/08/05  01:12:42  root
 * Initial revision
 *
 *      
 *
 *
\*/

#include	"Mover.h"
#include	"Criteria.h"


#define BD "N:\\net\\mail"


void
mainloop( void )
	{

	yes_criteria		allways;

	sent_criteria		sent;
	received_criteria	recd;

	to_user_criteria	to_dz("Dmitry Zavalishin");
	to_user_criteria	to_ks("Kira Stratonnikova");
	to_user_criteria	to_aa("Aleksey Aristov");
//	to_user_criteria	to_postm("Kira Stratonnikova");

	const char *main_box	= BD ;
	const char *recd_box	= BD "\\Received";
	const char *sent_box	= BD "\\Sent";
	const char *auto_box	= BD "\\auto\\to";

	const char *dz_box	= BD "\\dz";
	const char *ks_box	= BD "\\Kirka";
	const char *aa_box	= BD "\\aav";

//	const char *postm_box	= BD "\\PostMast";

	// Autosender

	move( auto_box, main_box, allways, No );

	
	// rec'd & sent
	move( main_box, recd_box, recd, No );
	move( main_box, sent_box, sent, No );

	move( dz_box, recd_box, recd, No );
//	move( ks_box, recd_box, recd, No );
	move( aa_box, recd_box, recd, No );

	// Moveback
	move( dz_box, main_box, to_dz, Yes );
	move( ks_box, main_box, to_ks, Yes );
	move( aa_box, main_box, to_aa, Yes );

	// move to
	move( main_box, dz_box, to_dz, No );
	move( main_box, ks_box, to_ks, No );
	move( main_box, aa_box, to_aa, No );




	}



