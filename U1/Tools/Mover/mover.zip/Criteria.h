/************************ Mail Mover ***************************\
 *
 *      Copyright (C) 1991-1994 by Infinity Soft
 *
 *      Module  :       M
 *
 *      $Log: Main.c $
 *
 *      
 *
 *
\*/

#include		"Fido_Msg.h"



class criteria
	{

public:
	virtual bool	select( const fido_msg &m ) = 0;

	};


class yes_criteria : public criteria
	{

public:
	virtual bool	select( const fido_msg &m ) { return Yes; };

	};


class sent_criteria : public criteria
	{

public:
	virtual bool	select( const fido_msg &m ) { return m.attr() & FF_Sent ? Yes : No; }

	};


class received_criteria : public criteria
	{

public:
	virtual bool	select( const fido_msg &m )  { return m.attr() & FF_Recd ? Yes : No; }

	};


class to_user_criteria : public criteria
	{
	string	user;


public:

	to_user_criteria( const string & s ) { user = s; };

	virtual bool	select( const fido_msg &m )
		{
		fido_user	u;
		m.get_to( u );
		return stricmp( user.c_str(), u.name() ) == 0 ? Yes : No;
		}

	};





bool
move(   const char *from_dir, const char *to_dir, criteria &crit, bool Invert );
