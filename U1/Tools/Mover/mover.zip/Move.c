/************************ Mail Mover ***************************\
 *
 *      Copyright (C) 1991-1994 by Infinity Soft
 *
 *      Module  :       M
 *
 *      $Log: Main.c $
 *
 *      
 *
 *
\*/

#include		"Mover.h"
#include		"Criteria.h"

#include		<FIDO_Msg.h>


#define INCL_DOSFILEMGR   /* File Manager values */
#include <os2.h>
#include <stdio.h>
#include <dirent.h>


static bool
msg_file( const char *fn )
	{
	
	char	ext[20];
	_splitpath( fn, NULL, NULL, NULL, ext);


	if( stricmp( ext, "msg" ) == 0 )
		return Yes;

	if( stricmp( ext, ".msg" ) == 0 )
		return Yes;

	return No;
	}


bool
match(	const char *dir, int msg_no, criteria &crit )
	{
	fido_msg	fm;
	
	if( fm.attach( dir, msg_no ) == Err )
		{
		error( EI_None, "Can't open message '%d.msg'", msg_no );
		return Err;
		}

	if( crit.select( fm ) ) 
		{
		fm.detach();
		return Yes;
		}

	fm.detach();						// Forget it.

	return No;
	}







bool
move_one( const char *file, const char *dir )
	{
	
	int	mn = find_last_msg( dir ) + 1;
	int	rc;

	int	try_count = 20;

	while( try_count-- > 0 )
		{
		char	out[200];

		sprintf( out, "%s\\%d.msg", dir, mn );

		fprintf( stdout, "%s -> %s\n", file, out );

		if( (rc = DosCopy(file, out, 0 )) == 0 )
			{
			chmod( file, 0666 );
			if( unlink( file ) )
				{
				error( EI_Full, "Can't delete %s", file );
				chmod( out, 0666 );
				unlink( out );
				}

			return Ok;
			}
		else
			{

			if( rc == 5 )
				{
				mn++;
				continue;
				}

			error( EI_Full, "Can't copy: %d", rc );
			return Err;
			}


		}

	return Err;
	}






bool
move(	const char *from_dir, const char *to_dir, criteria &crit, bool Invert )
	{

	DIR *		dirp;
	dirent *	de;
	
	dirp = opendir( from_dir );
	if( dirp == NULL )
		fatal( EC_IO_Error, EI_Full, "Can't open directory (%s)", (const char *)from_dir );

	bool	processed = No;

	while( ( de = readdir( dirp )) != NULL ) 
		{
		int			mno;

		if( !msg_file( de->d_name ) )
			continue;

		mno = atoi( de->d_name );

		char	in_name[200];

		sprintf( in_name, "%s\\%d.msg", from_dir, mno );

		if( 
			(!Invert) && (match( from_dir, mno, crit ) == Yes)
			||
			(Invert) && !(match( from_dir, mno, crit ) == Yes)
		)
			move_one( in_name, to_dir );

		}


	closedir( dirp );


	return Ok;
	}


