/************************ Gate remote control ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :	Send resulting letter
 *
 *      $Log:   C:/net/gate/fido2uu/vcs/send_ack.c_v  $
 *      
 *
\*/

#include	"gremote.h"
//#include	"..\version.h"


#include	<dir.h>
#include	<time.h>
#include	<errno.h>


extern void		put_track( fido_msg *fm );


void
send_letter( fido_msg *orig ) {
	fido_msg	fm;
	fmsg_attr	at;
	fido_addr	to;
	long		t;

	time( &t );

	if( fm.new_msg( conf.netmail_dir ) == Err )
		fatal( 2, "Can't create message file" );

	orig->get_from( &to );
	fm.set_to( &to );

	fm.set_from( &conf.our_addr );

	fm.set_date( ctime( &t ) );

	fm.get_attr( &at );
	at.Private				= (uint)Yes;
	at.KillSent				= (uint)Yes;
	at.Local				= (uint)Yes;
	at.IsReturnReceipt		= (uint)Yes;
	fm.set_attr( at );


	fm.set_subj("Fido2UU Reception Ack");




	fm.rewind();

	fm.puts(
		">>> This letter confirms reception of your message\r\n"
		">>> to Relcom by Fido2UU gate.  Log track follows:\r\n"
		);

	fm.puts( "\r\n");

	put_track( &fm );					// Fill it with track buffer

	fm.puts( "\r\n");

	fm.flush();
	fm.detach();						// Send it.

	}



