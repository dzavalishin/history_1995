/************************ UU2 News Rules Sender ***************************\
 *
 *	Copyright (C) 1991 by Infinity Soft
 *
 *	Module 	:	Main
 *
 *      $Log:   Q:/news/unbatch/sendrule/vcs/sendrule.c_v  $
 *      
 *         Rev 1.0   25 Oct 1992 05:02:00   dz
 *      Initial revision.
 *
 *
\*/

#include	"sendrule.h"
#include	<new_usr.h>
#include	"local.h"
#include	"db.h"

#include	<log.h>

#include	<uu2io.h>



bool
send_group_rules( const char *group, const char *address )
	{
	char    filename[200];

	if( !rules_sender::active() ) return Ok;

    debug("Looking for group rules for %s", group );

    if( find_rules_file( group, filename ) != Ok )
        {
        debug("Rules file not defined - skipping");
        return Ok;
        }

    debug("Checking for new pair - (%s,%s)", group, address );

    if( is_unknown_pair( group, address ) == Yes )
        {
        log("u", "Sending group %s rules (file %s) to %s", group, filename, address );
        return do_send_rules( address, filename );
        }

    return Ok;
    }


