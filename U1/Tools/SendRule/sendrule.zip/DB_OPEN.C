/************************ UU2 News Rules Sender ***************************\
 *
 *	Copyright (C) 1991 by Infinity Soft
 *
 *	Module 	:	Users base access - general
 *
 *      $Log:$
 *
 *
\*/

#include    <style.h>
#include	<stdio.h>
#include	<stdlib.h>

#include	"db.h"

#include	<log.h>



bool                sr_base_open = No;

static TABLEHANDLE  sr_table_h = -1;


static bool         sr_open_base( void );
static bool         sr_creat_base( const char *name );



//�
//� Here is the main entry point to the database access system
//�

bool
is_unknown_pair( const char *group, const char *address )
    {
    if( sr_base_open != Yes )
        sr_open_base();

	if( sr_base_open != Yes )
        return Err;

	return sr_base_search( group, address, sr_table_h );
    }



static bool
sr_open_base( void )
	{
	char         *sr_base_dir = getenv("UU2");
	char         bname[200];
	int          ec;
	static bool  inited = No;

	if( sr_base_dir == NULL )
		fatal( EC_Incorrect_Setup, EI_None, "UU2 environment variable is not defined!");

   sprintf( bname, "%s\\sendrule", sr_base_dir );

   PXSetDefaults( 8, 1, 2, 4, 4, NULL );

	if( !inited )
		{
		ec = PXNetInit( sr_base_dir, OTHERNET|LOCALSHARE, DEFUSERNAME );
		if( ec != PXSUCCESS )
			{
            error( EI_None, "Can't init Paradox Engine: %Fs", PXErrMsg( ec ) );
            return Err;
            }
        inited = Yes;
        }

   PXSetHWHandler( 1 );

   int eflag = 1;
   if( PXTblExist( bname, &eflag ) == PXSUCCESS && eflag == 0 )
       if( sr_creat_base( bname ) == Err )
           return Err;

   ec = PXTblOpen( bname, &sr_table_h, 0, 0 );
   if( ec != PXSUCCESS )
       {
       error( EI_None, "Can't open table (%s): %Fs", bname, PXErrMsg( ec ) );
       return Err;
       }

   sr_base_open = Yes;
   return Ok;
   }




	/*************************************************************
                           Create database
    *************************************************************/

char fg_name[] = "News Group";
char fa_name[] = "User Address";

static char *ph_fields[] = { fg_name, fa_name };
static char *ph_types[] =  { "A60",   "A60"   };


static bool
sr_creat_base( const char *name )
    {
    log( "#", "Creating SendRules database (%s)", name );
    if( PXTblCreate( (char *)name, 2, ph_fields, ph_types ) != PXSUCCESS )
       {
       error( EI_None, "Can't create database %s", name );
       return Err;
       }

    FIELDHANDLE fh = 1;
    if( PXKeyAdd( (char *)name, 2, &fh, PRIMARY ) != PXSUCCESS )
        {
        error( EI_None, "Can't create primary index %s", name );
        return Err;
        }

    return Ok;
    }



static void
sr_close_base( void )
    {
    if( sr_base_open )
        PXTblClose( sr_table_h );

    PXExit();
    }


#pragma exit sr_close_base
