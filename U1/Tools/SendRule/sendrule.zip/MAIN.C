/************************ Rules sender ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :       Main
 *
 *      $Log:   Q:/fido2uu/vcs/main.c_v  $
 *
 *
\*/

#include		<stdlib.h>
#include		<stdio.h>

#include		<setup.h>
#include		"sendrule.h"
#include		<new_usr.h>
#include		"\version.h"

extern uint _stklen = (10*1024u);


char program_name[] = "SendRules " UU2_VER_STR " (" __DATE__ ")";

static void				usage( char *msg );

void
main( int ac, char **av ) {

	get_setup();

	if( conf.announce_module )
		fprintf( stderr, "%s, copyright (C) 1991,92 by Dmitry Zavalishin\n", program_name );


	ac--;
	av++;

	while( ac-- ) {
		char *ap = *av++;
		if( *ap != '-' ) {
			usage("Error: not a flag on command line\n\n");
			exit(1);
			}

		for( ap++; *ap; ap++ ) {
			switch( *ap  ) {
//			case 'q':
//				f_silent = Yes;
//				break;

//			case 'k':
//				f_keeporig = Yes;
//				break;

			default:
				usage("Error: Bad flag\n\n");
				exit(1);
				break;
				} /* switch */
			}
		}

	rules_sender::for_each_address( send_group_rules );

	exit(0);
	}



	/*************************************************************
							 Usage info
	*************************************************************/


void
usage( char *msg ) {
	printf(
		"UU2 Rules Sender vers. " UU2_VER_STR " (" __DATE__ ")\n"
		"Copyright (C) 1992 by Dmitry Zavalishin.\n"
		"\n"
		"%s\n\n"
		"Usage: sendrule\n"
//		"Flags:\n"
//        "       -q     \t- Keep silence\n"
		,
		msg
		);
	}

