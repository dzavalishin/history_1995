/************************ UU2 News Rules Sender ***************************\
 *
 *	Copyright (C) 1991 by Infinity Soft
 *
 *	Module 	:	Find rules file for given group
 *
 *      $Log:   Q:/news/unbatch/sendrule/vcs/findfile.c_v  $
 *      
 *         Rev 1.0   25 Oct 1992 05:02:06   dz
 *      Initial revision.
 *
 *
\*/


#include    "local.h"

#include    <stdio.h>
#include    <string.h>
#include    <uu2io.h>
#include	<ctype.h>

#include    <log.h>
#include	<setup.h>



static FILE *glf = NULL;

static void
open_glf( void )
    {

	debug("Trying to open glf: %s", (const char *)conf.rulelist_file );
	if( (glf = fopen( conf.rulelist_file, "r" )) == NULL )
		error( EI_Full, "Can't open rules list file (%s)", (const char *)conf.rulelist_file );
	}

static void
close_glf( void )
	{
	if( glf != NULL )
		fclose( glf );

	glf = NULL;
	}

#pragma exit close_glf

bool
find_rules_file( const char *group, char *filename )
	{
    const int   bufl = 520;
    char        buf[ bufl ];

    if( glf == NULL )
        open_glf();

    if( glf == NULL )
        return Err;

    fseek( glf, 0L, SEEK_SET );
    while( fgets( buf, bufl, glf ) != NULL )
        {
        char    g[256], f[256], *p;

        if( (p = strpbrk( buf, ";\r\n" )) != NULL )
            *p = '\0';

        for( p = buf; isspace( *p ); p++ )
            ;

        if( strlen( p ) == 0 )
            continue;

        if( sscanf( p, "%255s %255s", g, f ) != 2 )
			{
            error( EI_None, "Rules file format incorrect: '%s'", p );
            continue;
			}

        if( stricmp( g, group ) )
            continue;

        if( access( f, 04 ) != 0 )
            {
			error( EI_Full, "Have no access to file '%s'", f );
			return Err;
			}

		strcpy( filename, f );
		return Ok;
		}

	return Err;
	}


