/************************ UU2 Library test ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :       Main
 *
 *      $Log:   C:/net/gate/fido2uu/vcs/main.c_v  $
 *
 *
\*/

#include        <style.h>
#include        <stdlib.h>
#include        <stdio.h>
#include        <string.h>

#include		"setup.h"
//#include		"log.h"

#include	"sendrule.h"


char program_name[] = "CheckLib  (" __DATE__ ")";



void
main( void ) {

	get_setup();

    char        g[100], a[100];

    printf("Group: ");  gets(g);
    printf("Addr : ");  gets(a);

    printf( "Result: %d\n\n", (int)send_group_rules( g, a ) );

	exit(0);
	}

