/************************ UU2 News Rules Sender ***************************\
 *
 *	Copyright (C) 1991 by Infinity Soft
 *
 *	Module 	:	Compose & send message
 *
 *      $Log:   Q:/tools/sendrule/vcs/send.c_v  $
 *      
 *         Rev 1.1   04 Mar 1993 22:45:24   dz
 *      Working version.
 *      
 *         Rev 1.0   25 Oct 1992 05:01:48   dz
 *      Initial revision.
 *
 *
\*/

#include	"local.h"
#include	"version.h"
#include	"recode.h"

#include	<stdio.h>
#include	<uu2io.h>
#include	<time.h>
#include	<process.h>

#include	<log.h>
#include	<setup.h>
#include    <rfc.h>
#include	<datec.h>


static bool          add_file( FILE *fp, const char *name );

bool
do_send_rules( const char *address, const char *file )
    {
    char    buf[200];
    FILE    *lf;
    time_t  t = time( NULL );
    static  id_count = 0;

    fprintf( stderr, "Sending rules from %s to %s ...\n", file, address );
    log( "u", "Sending rules from %s to %s ...\n", file, address );

    lf = tmpfile();
    if( lf == NULL )
        {
        error( EI_Full, "Can't create temorary file" );
        return Err;
        }

    mk_from_( buf, "postmaster" );                      // Leading From_
    fputs( buf, lf );

	fprintf( lf, "From: Gate Keeper <postmaster@%s>\n", (const char *)conf.def_domain );
	fprintf( lf, "To: Dear FIDO Guest <%s>\n", address );
	fprintf( lf, "Subject: Welcome to the FIDO Echo-Group!\n" );
	fprintf( lf, "Date: %s\n", timeline( t, (const char *)conf.tz ) );
    fprintf( lf, "Message-ID: <SendWelcome.%ld.%d@%s>\n",
			 (long)t, id_count++, (const char *)conf.def_domain );
	fprintf( lf, "X-Gate: UU2 %s\n", UU2_VER_STR );
    fprintf( lf, "\n" );                                // End of header

    if( add_file( lf, file ) == Err )
        {
        fclose( lf );
        return Err;
        }

    if( ferror( lf ) )
        {
        error( EI_Full, "Error writing to temp. file" );
        fclose( lf );
        return Err;
        }

    int     sstdin = dup( 0 );

    if( sstdin < 0 )
        {
        error( EI_Full, "Can't dup( stdin )" );
        fclose( lf );
        return Err;
        }

    fflush( lf );
    lseek( fileno( lf ), 0L, SEEK_SET );
    close( 0 );
    if( dup( fileno( lf ) ) != 0 )
        {
        fclose( lf );
        error( EI_None, "Can't dup to fd 0");
        return Err;
        }

	int		ex;

	debug("spawning %s %s", (const char *)conf.rmail_exe_name, address );
	ex = spawnlp( P_WAIT, (char *)(const char *)conf.rmail_exe_name, (char *)(const char *)conf.rmail_exe_name, address, NULL );

	if( ex != 0 && ex != conf.rmail_exitr )
		{
		error( EI_Full, "%s returned exit code %d", (const char *)conf.rmail_exe_name, ex );
		fclose( lf );
		return Err;
		}

    fclose( lf );

    close( 0 );
    dup( sstdin );
    close( sstdin );

	return Ok;
	}




		/*********************************************
         		Add file contents
        *********************************************/


static bool
add_file( FILE *fp, const char *name )
    {
	recoder     rec( conf.code_fu );            // Get codetable
	if( !rec.valid() )							// Can't init recoder
		fatal( EC_Incorrect_Setup, EI_None, "Can't find codetable '%s'", (const char *)conf.code_fu );

	FILE    *in = fopen( name, "rt" );
	if( in == NULL )
        {
        error( EI_Full, "Can't open %s", name );
        return Err;
        }

    char    buf[200];
    while( fgets( buf, 200, in ) != NULL )
		{
		rec.rs( buf );
		fputs( buf, fp );
		}

    if( ferror( in ) )
        {
        error( EI_Full, "Problems reading input file %s", name );
        fclose( in );
        return Err;
        }

    fclose( in );
    return Ok;
    }





