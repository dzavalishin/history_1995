/************************ UU2 News Rules Sender ***************************\
 *
 *	Copyright (C) 1991 by Infinity Soft
 *
 *	Module 	:	Search/create record
 *
 *      $Log:$
 *
 *
\*/

#include    <style.h>
#include	<stdio.h>

#include	"db.h"

#include	<log.h>


//�
//� Returns Yes if record was added, Err if error, No otherwise.
//�

bool
sr_base_search( const char  *group, const char  *address, TABLEHANDLE th )
    {
    RECORDHANDLE    r;
    FIELDHANDLE     f_g, f_a;
    int             ec;


    ec = PXFldHandle( th, (char *)fg_name, &f_g )
       | PXFldHandle( th, (char *)fa_name, &f_a );
    if( ec != PXSUCCESS )
        {
        error( EI_None, "Can't get field numbers" );
        return Err;
        }

    ec = PXRecBufOpen( th, &r );
    if( ec != PXSUCCESS )
        {
        error( EI_None, "Can't open record buffer: %Fs", PXErrMsg( ec ) );
        return Err;
        }

    if( PXPutAlpha( r, f_g, (char *)group ) != PXSUCCESS
    || PXPutAlpha( r, f_a, (char *)address ) != PXSUCCESS )
        {
        error( EI_None, "Unable to put alpha value to record buf");
        PXRecBufClose( r );
        return Err;
        }

    ec = PXSrchKey( th, r, 2, SEARCHFIRST );
    if( ec != PXSUCCESS && ec != PXERR_RECNOTFOUND )
        {
        error( EI_None, "Can't search for record: %Fs", PXErrMsg( ec ) );
        PXRecBufClose( r );
        return Err;
        }

    if( ec == PXSUCCESS )
        {
        PXRecBufClose( r );
        return No;
        }

// Record was not found - ok, add it!

    ec = PXRecAppend( th, r );
    if( ec != PXSUCCESS )
        {
        error( EI_None, "Can't add record: %Fs", PXErrMsg( ec ) );
        PXRecBufClose( r );
        return Err;
        }

    ec = PXRecBufClose( r );
    if( ec != PXSUCCESS )
        {
        error( EI_None, "Can't close record: %Fs", PXErrMsg( ec ) );
        return Err;
        }

    ec = PXSave();
    if( ec != PXSUCCESS )
        {
        error( EI_None, "Can't save data to base: %Fs", PXErrMsg( ec ) );
        return Err;
        }

    return Yes;
    }


