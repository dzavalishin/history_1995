/******************** Mail mover ***********************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :       Mail dir list
 *
 *      $Log:   C:/dianet/simple/top/vcs/tr_proc.c_v  $
 *
 *
\*/

#include	"lpoints.h"
#include	"maildir.h"

#include	<stdio.h>
#include	<dirent.h>
#include	<string.h>
#include	<bag.h>



/***************************************************************************\
							Add dir to bag
\***************************************************************************/

static bool
add_dir( Bag *b, int dir )
	{
	maildir		*md = new maildir;

	if( md == Object::ZERO )
		{
		error("Can't allocate memory!");
		return Err;
		}

	md->point = dir;

	b->add( *(Object*)md );
	return Ok;
	}



bool
load_addresses( Bag &b, char *root )
	{
	DIR				*d;
	struct dirent	*ent;

	d = opendir( root );
	if( d == NULL )
		{
		error("Can't opendir(\"%s\")", root );
		return Err;
		}

	while((ent = readdir(d)) != NULL)
		{
		int	dn;

		strupr( ent->d_name );

		debug( "#", "Dir: %s", ent->d_name );

		if( sscanf( ent->d_name, "MAIL%d", &dn ) == 1 )
			{
			if( add_dir( &b, dn ) == Err )
				{
				error("Can't add dir to list");
				return Err;
				}

			}
		}

	return Ok;
	}


/***************************************************************************\
				test!
\***************************************************************************/
/*
static bool
deliver( Bag &b )
	{

	ContainerIterator	&it = b.initIterator();
	DeliveryAddress		*da;

	debug("Delivering!" );

	for(; (int)it;)
		{
		da = &((DeliveryAddress&)it++);

		if( !da->resolved )
			{
			error("Non-resolved address found during delivery! Program internal error!");
			continue;
			}

		if( da->is_deliver_with )
			{
			char	*an = da->deliver_with;
			char	args[100];

			debug("Delivering '%s' with '%s'", da->deliver_to, an );
			if( get_agent_record( args, 100, "c:\\dianet\\conf\\agents.top", an ) == Err )
				{
				error("Can't find definition for agent '%s' in file '%s'", an, "???" );
				continue;
				}

			debug("Agent definition: '%s'", args );
			continue;
			}

		if( da->remote )
			{
			debug("Delivering '%s' to bottom router", da->deliver_to );
			continue;
			}

		error("No delivery method for '%s'!!", da->deliver_to );
		}

	return Ok;
	}


*/