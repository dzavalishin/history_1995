/************************ FIDO2UU ***************************\
 *
 *	Copyright (C) 1991 by Infinity Soft
 *
 *	Module 	:	Attachments encoding engine
 *
 *      $Log:   C:/net/gate/fido2uu/vcs/encode.c_v  $
 *      
 *         Rev 1.0   04 Feb 1992 00:07:18   dz
 *      Initial revision.
 *
 *
\*/

//	TODO
//
//	- This stuf doesn't check for errors!
//	- ATOB
//


#include	"fido2uu.h"

#include	"encode.h"
#include	<ctype.h>



static bool		extract_name( char *name, char *names, bool ll );

bool
encode_attaches( fido_msg *fm, FILE *out, long *files_sent )
	{
	fmsg_attr	at;
	char		names[80];							// File names list
	char		fn[80];								// Current file name
	bool		ll;									// Local letter

	fm->get_attr( &at );							// Get msg attributes
	if( !at.FileAttached )							// File attached?
		return Ok;									// No. All done.


	ll = at.Local ? Yes : No;						// Local letters have full
													// file names in subject

	fm->get_subj( names );							// Get file names
	log( "fu", "Attaches: %s", names );				// Log activity

	while( extract_name( fn, names, ll ) == Yes )	// Extract one name
		{
		debug("Encoding '%s'", fn );
		uuencode( fn, out );						// Encode it

		(*files_sent)++;

		if( !at.Local )								// Local message?
			{
			debug("Deleting '%s'", fn );
			chmod( fn, 0666 );						// --> R/W mode
			unlink( fn );							// Kill � �p��� 䥭�
			}
		}

	return Ok;										// ����쪨...
	}



static bool
extract_name( char *name, char *names, bool ll ) {
	char	*beg = names;							// Start of string
	char	nbuf[50], *np;

	while( isspace( *names ) )						// Skip spaces
		names++;

	if( *names == '\0' )							// No more names?
		return No;									// Done

	np = nbuf;
	while( *names && !isspace( *names ) )			// Get one
		*np++ = *names++;

	*np = '\0';

	strcpy( beg, names );							// Move rest of string

	if( ll )										// Local letter
		strcpy( name, nbuf );						// Full name
	else
		sprintf( name, "%s\\%s",					// Add inbound directory
			conf.netfile_dir, nbuf );

	return Yes;
	}















