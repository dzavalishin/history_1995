/************************ FIDO to UUCP convertor ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :	Separator
 *
 *      $Log:   C:/net/gate/fido2uu/vcs/select.c_v  $
 *      
 *         Rev 1.3   04 Feb 1992 00:10:16   dz
 *      Ignore in-Transit messages!
 *      
 *         Rev 1.2   29 Aug 1991 07:06:36   dz
 *      Reckognition of messages to user@domain added.
 *      
 *         Rev 1.1   29 Aug 1991 06:38:02   dz
 *      Log record shortened
 *      
 *         Rev 1.0   27 Aug 1991 02:47:18   dz
 *      Initial revision.
 *
 *
\*/


#include	"fido2uu.h"

#include	<ctype.h>



bool
select( fido_msg *fm ) {
	fmsg_attr	at;
	fido_addr	to;

	fm->get_attr( &at );
	fm->get_to( &to );

	if( at.Sent || at.InTransit )
		return No;

	if( !conf.to_any_addr )					// Take dest. address in account
		{
		if( (
			to.zone		!=	conf.our_addr.zone	||
			to.net		!=	conf.our_addr.net	||
			to.node		!=	conf.our_addr.node	||
			to.point	!=	conf.our_addr.point
			) &&
			(
			to.zone		!=	conf.news_addr.zone	||
			to.net		!=	conf.news_addr.net	||
			to.node		!=	conf.news_addr.node	||
			to.point	!=	conf.news_addr.point
			) )
			return No;
		}

	if( strchr( to.name, '@' ) ) {			// Seems to be user@domain
		log( "a", "-----> fido to '%s', converting",	to.name );
		return Yes;
		}


	char	*a, *b;
	bool	eq = No;

	a = conf.our_addr.name;
	b = to.name;

	while( 1 ) {
		if( tolower( *a ) == tolower( *b ) ) {
			if( *a == '\0' ) {
				eq = Yes;
				break;
				}
			a++; b++;
			continue;
			}

		if(
			(*a == ' ' && *b == '_') ||
			(*b == ' ' && *a == '_')
		  ) {
			a++; b++;
			continue;
			}

		eq = No;
		break;
		}

	if( eq == Yes )
		log( "a", "-----> to '%s', converting",	to.name );

	return eq;
	}














