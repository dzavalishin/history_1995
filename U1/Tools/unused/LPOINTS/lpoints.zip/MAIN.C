/************************ Local points mail mover ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :       Main
 *
 *      $Log:   C:/net/gate/fido2uu/vcs/main.c_v  $
 *      
 *
 *
\*/

#include        "lpoints.h"
#include        "..\..\version.h"




char program_name[] = "lpoints " UU2_VER_STR " (" __DATE__ ")";


static void				usage( char *msg );

void 
main( int ac, char **av ) {

	get_setup();

    if( conf.our_addr.point )
        {
        printf("This program can't be used in point environment, sorry.\n");
        exit(33);
        }

	ac--;
	av++;

	while( ac-- ) {
		char *ap = *av++;
		if( *ap != '-' ) {
			usage("Error: not a flag on command line\n\n");
			exit(1);
			}

		for( ap++; *ap; ap++ ) {
			switch( *ap  ) {
//            case 'q':
//                f_silent = Yes;
//                break;

//            case 'k':
//                f_keeporig = Yes;
//                break;

			default:
				usage("Error: Bad flag\n\n");
				exit(1);
				break;
				} /* switch */
			}
		}

	// Perform conversion

//  debug("Don't delete msg        : %s", f_keeporig    ? "Yes" : "No" );

    //
    //	Check for incompartible flags
    //

	mainloop();

	exit(0);
	}



	/*************************************************************
							 Usage info
	*************************************************************/


void
usage( char *msg ) {
	printf(
        "Local points mail mover vers. " UU2_VER_STR " (" __DATE__ ")\n"
		"Copyright (C) 1991 by Dmitry Zavalishin.\n"
		"\n"
		"%s\n"
//        "Usage: lpoints [-flags]\n"
//        "\n"
//        "Flags:\n"
//        "\n"
//        "       -q     \t- Keep silence\n"
//		"       -k     \t- Keep (don't delete) original messages\n"
		"\n",
		msg
		);
	}

