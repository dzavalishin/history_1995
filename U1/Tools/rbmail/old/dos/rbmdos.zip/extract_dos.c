void
do_one_piece( const char *headerline )
	{
	char diagheader[max_header];
	char *rargs[100];
	const char *p;
	unsigned rcsum, csum;
	long     len;

	//	Parse header line
	rargs[0] = NULL;
	strcpy(diagheader, headerline);

	/* Length */
	p = headerline;
	len = 0;
	for( int i = 0 ; i < 7 ; i++ )
		{
		unsigned char c = *p++;

		if( c == ' ' || c == '\t' )  // Oh yeah. Some batches have 6 digits :(
			{
			p--;
			break;
			}

		if( '0' > c || c > '9' )
			corrupt_hdr( "bad length", diagheader );
		len = (len*10) + (c-'0');
		}

	if( *p++ != ' ' )
		corrupt_hdr( "no space after length", diagheader );

	/* Checksum */
	rcsum = 0;
	for( i = 0 ; i < 4 ; i++ )
		{
		unsigned char c = *p++;
		rcsum <<= 4;
		if( '0' <= c && c <= '9' )
			rcsum |= c-'0';
		else if( 'A' <= c && c <= 'F' )
			rcsum |= c-'A'+0xa;
		else if( 'a' <= c && c <= 'f' )
			rcsum |= c-'a'+0xa;
		else
			corrupt_hdr( "bad checksum field", diagheader );
		}

	if( *p != ' ' )
		corrupt_hdr( "no space after checksum", diagheader );

	/* Destination addresses */
	if( ! *p )
		corrupt_hdr( "no dest address", diagheader );


	char reason[200];
	if( load_args( rargs, p, reason ) != 0 )
		corrupt_hdr( reason, diagheader );


	// Read all the stuff in

	FILE *Letter = tmpfile();

	if( Letter == NULL )
		corrupt_hdr("Can't create temp file", diagheader );

	int real_len = 0;
	if( (copy_file( stdin, Letter, len )) != 0 )
		dump_off( "Can't read data", diagheader, Letter, real_len );

//	Letter[len] = '\0';

	// Calc. checksum
/*
	csum = 0;
	for( char *cp = Letter; *cp; cp++ )
		{
		if( csum & 01 )
			csum = (csum>>1) + 0x8000;
		else
			csum >>= 1;
		csum += *cp;
		csum &= 0xFFFF;
		}

	if( rcsum != csum )
		dump_off( "Checksum error", diagheader, Letter, real_len );
*/
	if( send_it( Letter, rargs ) != 0 )
		dump_off( "Can't send", diagheader, Letter, real_len );

	for( char **ap = &rargs[1]; *ap; ap++ )
		free( *ap );

	fclose( Letter );
	}
