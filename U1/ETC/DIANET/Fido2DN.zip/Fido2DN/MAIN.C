/************************ Fido to DiaNet ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :       Main
 *
 *      $Log:   Q:/dianet/fido2dn/vcs/main.c_v  $
 *      
 *         Rev 1.6   01 Dec 1992 10:31:10   dz
 *      Starting Fido2DN
 *      
 *         Rev 1.5   28 Nov 1992 22:54:32   dz
 *      Announce
 *      
 *         Rev 1.4   23 Oct 1992 14:31:54   dz
 *      usage
 *      
 *         Rev 1.3   12 Jul 1992 13:33:00   dz
 *      Stack size increased to 10K
 *      
 *         Rev 1.2   18 Jun 1992 10:31:32   dz
 *      Copyright change, cosmetics
 *      
 *         Rev 1.1   29 Aug 1991 06:41:22   dz
 *      Checkpoint.
 *      
 *         Rev 1.0   27 Aug 1991 02:47:16   dz
 *      Initial revision.
 *
 *
\*/

#include		"fido2dn.h"
#include		"\version.h"

extern uint _stklen = (10*1024u);


char program_name[] = "fido2dn " UU2_VER_STR " (" __DATE__ ")";


bool		f_silent		= No;		// Don't chat
bool		f_keeporig		= No;		// Keep original message


static void				usage( char *msg );

void
main( int ac, char **av ) {

	get_setup();

	if( conf.announce_module )
		fprintf( stderr, "%s, copyright (C) 1991,92 by NetDialogue\n", program_name );


	ac--;
	av++;

	while( ac-- ) {
		char *ap = *av++;
		if( *ap != '-' ) {
			usage("Error: not a flag on command line\n\n");
			exit(1);
			}

		for( ap++; *ap; ap++ ) {
			switch( *ap  ) {
			case 'q':
				f_silent = Yes;
				break;

			case 'k':
				f_keeporig = Yes;
				break;

			default:
				usage("Error: Bad flag\n\n");
				exit(1);
				break;
				} /* switch */
			}
		}

	// Perform conversion

//  debug("Don't delete msg        : %s", f_keeporig    ? "Yes" : "No" );

    //
    //	Check for incompartible flags
    //

	mainloop();

	exit(0);
	}



	/*************************************************************
							 Usage info
	*************************************************************/


void
usage( char *msg ) {
	printf(
		"UU2 Fido2DN vers. " UU2_VER_STR " (" __DATE__ ")\n"
		"Copyright (C) 1991,92 by NetDialogue.\n"
		"\n"
		"%s\n\n"
		"Usage: fido2dn [-flags]\n"
		"Flags:\n"
        "       -q     \t- Keep silence\n",
		msg
		);
	}

