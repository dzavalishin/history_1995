/************************ Fido to DiaNet ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :	Main conversion loop
 *
 *      $Log:   Q:/dianet/fido2dn/vcs/mainloop.c_v  $
 *      
 *         Rev 1.8   01 Dec 1992 10:31:26   dz
 *      Starting Fido2DN
 *      
 *         Rev 1.7   28 Nov 1992 23:08:04   dz
 *      String to const char *, style fixes
 *      
 *         Rev 1.6   23 Oct 1992 14:33:14   dz
 *      reorganization
 *      
 *         Rev 1.5   29 Jun 1992 15:38:10   dz
 *      Don't delete messages with 'Local' flag but withno
 *      'KillSent' one
 *      
 *         Rev 1.4   18 Jun 1992 10:32:02   dz
 *      Cosmetic changes
 *      
 *         Rev 1.3   04 Feb 1992 00:08:32   dz
 *      Count number of files sent. Incorrectly implemented -
 *      will only count one file-attach of all listed in the
 *      same message.
 *      
 *         Rev 1.2   11 Oct 1991 05:24:36   dz
 *      Error letter generation, return receipt mode,
 *      statistics update.
 *
 *         Rev 1.1   29 Aug 1991 06:40:34   dz
 *      MSG handling rewritten
 *
 *         Rev 1.0   27 Aug 1991 02:47:18   dz
 *      Initial revision.
 *
 *
\*/

#include	"fido2dn.h"

#include	<dir.h>
#include	<errno.h>


#define ATTRS2FIND  FA_RDONLY | FA_HIDDEN | FA_SYSTEM | FA_ARCH

void
mainloop( void )
	{
	ffblk		ff;
	char		mask[100];

	sprintf( mask, "%s\\*.msg", (const char *)conf.netmail_dir );
	debug("Search mask: `%s'", mask );

    if( findfirst( mask, &ff, ATTRS2FIND ) )
		{
		if( errno == ENOENT )
			{
			log( "#", "Nothing to do - no messages found" );
			return;
			}

		fatal( EC_IO_Error, EI_Full, "Findfirst");
		}


	do {
		fido_msg	fm;
		int			mno;


		mno = atoi( ff.ff_name );

		if( fm.attach( conf.netmail_dir, mno ) == Err )
			{
			error( EI_None, "Can't open message '%s'", ff.ff_name );
			continue;
			}

		if( select( &fm ) )						// Subject to convert ?
			{
			fmsg_attr	at;

			debug("Processing '%s\\msg.%d'", (const char *)conf.netmail_dir, mno );

			track_reset();						// Prepare to log tracking

			fm.get_attr( at );

			if( convert( fm ) == Err )			// Convert letter
				error_letter( &fm );			// Send letter back
			else
				{
				FILE	*flag;
				char	fn[200];

				if( at.ReturnReceiptRequest )	// Confirmation Request
					acknovledge_letter( &fm );	// Send confirmation

				sprintf( fn, "%s\\uumail.flg", (const char *)conf.flag_dir );
				if( ( flag = fopen( fn, "w" ) ) == NULL )
					error( EI_Full, "Can't create flag file '%s'", fn );
				else
					fclose( flag );


				// Update statistics


				fido_addr	from;
				fm.get_from( from );
				}


			at.Sent = (uint)Yes;				// Mark letter as sent
			if( !at.Local )                  	// Foreighn letter?
				at.KillSent = (uint)Yes;		// Force deletion
			fm.set_attr( at );

			fm.flush();
			fm.detach();						// Forget it.

			} /* if select */
		} while( findnext(&ff) == 0 );

	if( errno != ENOENT )
		fatal( EC_IO_Error, EI_Full, "Findnext");

	}



