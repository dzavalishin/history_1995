/************************ Fido to DiaNet ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :	Gate control lines parser
 *
 *      $Log:   Q:/dianet/fido2dn/vcs/gatectl.c_v  $
 *      
 *         Rev 1.2   01 Dec 1992 10:32:28   dz
 *      Starting Fido2DN
 *      
 *         Rev 1.1   11 Nov 1992 05:57:00   dz
 *      error()
 *      
 *         Rev 1.0   22 Mar 1992 19:30:58   dz
 *      Initial revision.
 *
 *
 *
\*/

#include	"fido2dn.h"
#include	<ctype.h>





#define		GATECTL_L	"%Gate:"
#define		GATECTL_N	6


bool
is_gate_control( uchar *s )
	{
	if( strnicmp( s, GATECTL_L, GATECTL_N ) )
		return No;
	s += GATECTL_N;
	while( isspace( *s ) )
		s++;

	debug("Gate control line: '%s'", s );

	/* Parsing to be written */
	error( EI_None, "Unknown control line: '%s'", s );

	return Yes;
	}


