/************************ Fido to DiaNet ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :	Convertor
 *
 *      $Log:   Q:/dianet/fido2dn/vcs/convert.c_v  $
 *
 *         Rev 1.20   01 Dec 1992 10:31:56   dz
 *      Starting Fido2DN
 *
 *         Rev 1.19   28 Nov 1992 23:10:34   dz
 *      String to const char *
 *
 *         Rev 1.18   11 Nov 1992 05:55:28   dz
 *      Using uucp_addr
 *
 *         Rev 1.17   23 Oct 1992 14:35:02   dz
 *      from_, return-receipt-to
 *
 *         Rev 1.16   18 Sep 1992 02:46:38   dz
 *      exit codes modified
 *      writing From_ only if not ache_uupc
 *
 *         Rev 1.15   29 Jun 1992 15:09:20   dz
 *      Code for ECHO2UU support removed,
 *      Temp. file creation logic rewritten - now creating
 *      unique file, so two or more copies of FIDO2UU can
 *      work simulteoncly in network or mtask environment.
 *
 *         Rev 1.14.1.0   29 Jun 1992 11:46:58   dz
 *      tempnam() used
 *
 *         Rev 1.14   29 Jun 1992 04:39:10   dz
 *      From_ line generation written
 *
 *         Rev 1.13   18 Jun 1992 10:36:06   dz
 *      Cc: address conversion
 *
 *         Rev 1.12   03 Mar 1992 19:29:34   dz
 *      Diagnostics moved to show From/To as early as possible
 *
 *         Rev 1.10   09 Feb 1992 00:56:52   dz
 *      Realname conversion fixed - space & dash now allowed to pass
 *
 *         Rev 1.9   09 Feb 1992 00:49:34   dz
 *      Domains checking added for non-registered users
 *
 *         Rev 1.8   09 Feb 1992 00:27:20   dz
 *      Cc: feature added
 *
 *         Rev 1.7   04 Feb 1992 00:13:36   dz
 *      rmail.exe interface generalized, external code table
 *      translation connected.
 *      NB!! Echo2UU now generates Message-Id itself.
 *
 *         Rev 1.6   27 Jan 1992 23:18:48   dz
 *      Attachments encoding engine connected
 *      Gate control lines parser started
 *      system() stuff removed
 *
 *         Rev 1.5   11 Oct 1991 05:22:50   dz
 *      Date: format corrected to be compartible with RFC822
 *
 *         Rev 1.3   24 Sep 1991 12:24:56   dz
 *      Optional headlines recognition/processing added
 *
 *         Rev 1.0   27 Aug 1991 02:47:14   dz
 *      Initial revision.
 *
 *
\*/


#include	"fido2dn.h"
#include	"\version.h"

#include	"\lib\date\datec.h"

#include	"encode.h"
#include	"recode.h"
#include	"freedom.h"
#include	"stat.h"

#include	"compose.h"

#include	<ctype.h>
#include	<share.h>
#include	<time.h>




#define		MAXCC		400

static bool		is_headline( uchar *s );
static bool		is_to_headline( uchar *s );
static bool		is_xcc_headline( uchar *morecc, int len, uchar *s );
static bool		is_cc_headline( uchar *ccdata, int len, uchar *s );
static bool		bad_cc_list( uchar *cc_list );


bool
convert( fido_msg &fm )
	{
	time_t				t;
	letter_composer		lc;

	vmem				attr;
	vmem				text;

	vmem				letter_vm;

	char		uu_to[100];						// Send to this address
	char		uu_cc[MAXCC];					// Carbon copies
	uucp_addr	uu_from;						// Send from this address
	bool		reg_user;						// Registered user
	bool		skip = No;
	fido_addr	fido_from;
	fmsg_attr   at;
	recoder     rec( conf.code_fu );            // Get codetable
//	char		temp_name[100];
	long 		bytes_sent;
	long		files_sent;

	time( &t );

	if( !rec.valid() )							// Can't init recoder
		fatal( EC_Incorrect_Setup, EI_None, "Can't find codetable '%s'", (const char *)conf.code_fu );

	if( (!letter_vm.valid()) || lc.open( letter_vm, letter::Multi ) == Err )
		fatal( EC_IO_Error, EI_Full, "Can't create letter" );

	attr.writef( "Received:  by %s (Fido2DN " UU2_VER_STR "); %s\n",
			(const char *)conf.domain,
			timeline( t, conf.tz )
			);

	attr.writef( "Organization: %s\n", (const char *)conf.organization );

	uu_cc[0] = '\0';							// Clear Cc field

	fm.get_from( fido_from );
	fm.get_attr( at );

	if( get_address( uu_to, &fm ) == Err )
		skip = Yes;

	if( skip || (get_from( &reg_user, uu_from, fido_from ) == Err) )
		skip = Yes;

	if( strlen( (const char *)uu_from ) == 0 )
		fatal( EC_UU2_Error, EI_None, "Can't build 'From:'???" );

	char	rep_fido[40];
	char	*cp;

	strncpy( rep_fido, fido_from.name(), 37 );
	rep_fido[36] = '\0';
	rec.rs( rep_fido );
	for( cp = rep_fido; *cp; cp++ )
		{
		if( (!isalnum( *cp )) && (*cp != ' ') && (*cp != '-') )
			*cp = '.';
		}

	if( at.ReturnReceiptRequest )   // Confirmation Request
		{
		log("#", "Adding return-receipt-to field" );
		attr.writef( "Return-Receipt-To: %s\n", (const char *) uu_from );
		}


	if( !skip )
		{
		char		subj[80];

		fm.get_subj( subj );

		fprintf( stderr, "From: %s\n", rep_fido );
		fprintf( stderr, "To  : %s\n", uu_to );

		log( "ua", "To: %s", uu_to );
		log( "ua", "From: %s <%s>", rep_fido, (const char *) uu_from );
		log( "u", "Subject: %s", subj );
		log( "u", "Date: %s", timeline( t, conf.tz ) );

		attr.writef( "To: %s\n", uu_to );
		attr.writef( "From: %s <%s>\n", rep_fido, (const char *) uu_from );
		attr.writef( "Message-Id: <%lX@%s>\n", t, (const char *)conf.domain );
		rec.rs( subj );
		attr.writef( "Subject: %s\n", subj );
		attr.writef( "Date: %s\n", timeline( t, conf.tz ) );
		}

	if( (!reg_user) && (!is_free_address( uu_to )))
		{
		error( EI_None, "Access to '%s' denied at this gate, sorry.", uu_to );
		skip = Yes;
		}

	if( !skip )
		{
		char				buf[1000];
		bool				header = Yes;
		letter_composer		ltc;
		vmem				text_data;
		vmem				text_attr;

		if(
				(!text.valid()) ||
				(!text_data.valid()) ||
				(!text_attr.valid()) ||
				ltc.open( text, letter::Single ) == Err )
			fatal( EC_IO_Error, EI_Full, "Can't create letter text segment" );

		fm.rewind();
		while( !fm.getl( buf ) )
			{
			char	morecc[80];
			char	fidocc[80];		// FIDO cc

			rec.rs( buf );

			if( header && is_headline( buf ) )
				{
				if( is_gate_control( buf ) == Yes )	// Gate control line
					continue;

				if( is_xcc_headline( morecc, 80, buf ) )
					{
					if( strlen( uu_cc ) > MAXCC )
						continue;

					attr.writef( "Cc: %s\n", morecc );
					if( strlen( uu_cc ) )
						strcat( uu_cc, " " );
					strcat( uu_cc, morecc );
					log( "ua", "Cc: %s", morecc );
					continue;
					}


				if( is_cc_headline( fidocc, 80, buf ) )
					{
					uucp_addr	convcc;	// Converted to uucp form FIDO cc

					if( fidoaddr2uuaddr( convcc, fidocc ) == Err )
						error( EI_None, "Can't convert FIDO Cc: %s", fidocc );
					else
						{
						attr.writef( "Cc: %s\n", (const char *) convcc );
						log( "ua", "FIDO Cc: %s", (const char *) convcc );
						}

					continue;
					}

				if( !is_to_headline( buf ) )
					{
					attr.writef( "%s\n", buf );		// Head line
					debug("Headline %s", buf );
					}

				continue;
				}

			if( header )
				header = No;

			text_data.writef( "%s\n", buf );				// Text line
			}

//		encode_attaches( &fm, fp, &files_sent );				// Put in attached files

		text_attr.writef("X-Source: FIDO message\n");
		text_attr.writef("X-FIDO-From: %s\n", (const char *)(String)fido_from );

		text_attr.seek(0);
		text_data.seek(0);

		ltc.add_type("S.S.TXT");
		ltc.add_attributes( text_attr );
		ltc.add_fragment( text_data );

		if( ltc.close() == Err )
			fatal( EC_IO_Error, EI_Full, "Can't close letter data segment" );

		}

//	bytes_sent = filelength( fileno( fp ));
	bytes_sent = 0L;  // :(

	if( (!reg_user) && bad_cc_list( uu_cc ))
		skip = Yes;

	attr.writef( "Deliver-To: %s %s\n", uu_to, uu_cc );

	attr.seek( 0 );
	text.seek( 0 );

	lc.add_type("N.L");
	lc.add_attributes( attr );
	lc.add_fragment( text );

	if( lc.close() == Err )
		fatal( EC_IO_Error, EI_Full, "Can't close letter" );

	if( send( letter_vm ) != Err )
		add_stat_fido( fido_from, uu_to, No,  /*files_sent ? Yes :*/ No, No, bytes_sent );

	return skip ? Err : Ok;
	}







		/*********************************************
					Headlines reckognition
		*********************************************/


bool
is_headline( uchar *s )						// Headline?
	{
	while( *s )
		{
		if( isalpha( *s ) || *s == '-' )
			{
			s++;
			continue;
			}

		if( *s == ':' )
			return Yes;

		return No;
		}

	return No;
	}


bool
is_to_headline( uchar *s )							// 'To:' ?
	{
	while( *s == ' ' || *s == '\t' )				// Skip ws
		s++;

	if( strnicmp( s, "to", 2 ) )					// to?
		return No;

	s += 2;											// skip "to"

	while( *s == ' ' || *s == '\t' )				// Skip ws
		s++;

	if( *s != ':' )									// ':' ?
		return No;

	return Yes;
	}



static bool
is_xcc_headline( uchar *morecc, int len, uchar *s )
	{
	while( *s == ' ' || *s == '\t' )				// Skip ws
		s++;

	if( strnicmp( s, "xcc", 3 ) )					// Cc?
		return No;

	s += 3;											// skip "to"

	while( *s == ' ' || *s == '\t' )				// Skip ws
		s++;

	if( *s != ':' )									// ':' ?
		return No;

	s++;
	while( *s )
		{
		*morecc++ = *s++;
		if( --len <= 0 )
			break;
		}

	*morecc = '\0';

	return Yes;
	}

static bool
is_cc_headline( uchar *ccdata, int len, uchar *s )
	{
	while( *s == ' ' || *s == '\t' )				// Skip ws
		s++;

		if( strnicmp( s, "cc", 2 ) )                // Cc?
		return No;

		s += 2;                                                                                 // skip "to"

	while( *s == ' ' || *s == '\t' )				// Skip ws
		s++;

	if( *s != ':' )									// ':' ?
		return No;

	s++;
	while( *s )
		{
		*ccdata++ = *s++;
		if( --len <= 0 )
			break;
		}

	*ccdata = '\0';

	return Yes;
	}




/****************************************************************************
							Cc: list checker
****************************************************************************/


static bool
bad_cc_list( uchar *ccl )
	{
	char	*p, *cclc;

	cclc = strdup( ccl );
	if( cclc == NULL )
		{
		error( EI_None, "Out of memory checking cc list" );
		return Yes;
		}

	p = strtok( cclc, " \t\r\n" );
	while( p )
		{
		debug("Testing cc: %s", p );
		if( !is_free_address( p ) )
			{
			free( cclc );
			error( EI_None, "Access denied: Bad cc: address '%s'", p );
			return Yes;
			}
		p = strtok( NULL, " \t\r\n" );
		}

	free( cclc );
	return No;
	}















