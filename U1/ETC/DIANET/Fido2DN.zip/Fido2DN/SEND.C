/************************ Fido to DiaNet ***************************\
 *
 *      Copyright (C) 1991 by Infinity Soft
 *
 *      Module  :	Sender
 *
 *      $Log:   Q:/dianet/fido2dn/vcs/convert.c_v  $
 *
 *
\*/


#include	"fido2dn.h"
//#include	"\version.h"


//#include	<ctype.h>
//#include	<share.h>
//#include	<time.h>


bool
send( vmem &let )
	{
	char				l_file[100];

	let.seek( 0 );

	for( int i = 10; i--; )
		{
//		sprintf( l_file, "%s\\let-XXXXXX", cconf.l_in_spool );
// BUG!
		sprintf( l_file, "%s\\let-XXXXXX", "c:\\dianet\\conf\\rspool.in" );
		mktemp( l_file );

		if( let.save( l_file ) == Ok )
			return Ok;
		}

	return Err;
	}
















