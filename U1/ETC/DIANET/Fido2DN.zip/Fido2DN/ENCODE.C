/************************ Fido to DiaNet ***************************\
 *
 *	Copyright (C) 1991 by Infinity Soft
 *
 *	Module 	:	Attachments insertion engine
 *
 *      $Log:   Q:/dianet/fido2dn/vcs/encode.c_v  $
 *      
 *         Rev 1.0   01 Dec 1992 10:30:12   dz
 *      Starting Fido2DN
 *      
 *         Rev 1.4   28 Nov 1992 22:52:30   dz
 *      Error fixed: list of directories was overwritten
 *      after first call.
 *      
 *         Rev 1.3   23 Oct 1992 14:32:06   dz
 *      error
 *      
 *         Rev 1.2   18 Sep 1992 02:44:56   dz
 *      Searching in given directories
 *      
 *         Rev 1.1   18 Jun 1992 10:30:04   dz
 *      Cosmetic
 *      
 *         Rev 1.0   04 Feb 1992 00:07:18   dz
 *      Initial revision.
 *
 *
\*/

//	TODO
//
//	- This stuff doesn't check for errors!
//


#include	"fido2dn.h"

#include	"encode.h"
#include	<ctype.h>
#include	<dir.h>



static bool		extract_name( char *name, char *names );
static bool		find_file_to_encode( char *found_fn, int ffn_len, char *fn );

bool
encode_attaches( fido_msg *fm, FILE *out, long *files_sent )
	{
	fmsg_attr	at;
	char		names[80];							// File names list
	char		fn[80];								// Current file name, relative
	char		found_fn[80];						// Current file name, absolute
	bool		ll;									// Local letter
	bool		was_an_error = No;

	fm->get_attr( at );								// Get msg attributes
	if( !at.FileAttached )							// File attached?
		return Ok;									// No. All done.


	ll = at.Local ? Yes : No;						// Local letters have full
													// file names in subject

	fm->get_subj( names );							// Get file names
	log( "fu", "Attaches: %s", names );				// Log activity

	while( extract_name( fn, names ) == Yes )		// Extract one name
		{

		if( !ll )									// Remote letter
			{
			if( find_file_to_encode( found_fn, 80, fn ) == Err )
				{
				error( EI_None, "File '%s' not found", fn );
				was_an_error = Yes;
				continue;
				}
			}
		else										// Local letter
			{
			strncpy( found_fn, fn, 80 );
			}

		debug("Encoding '%s'", fn );
//		uuencode( fn, out );						// Encode it

		(*files_sent)++;

		if( !at.Local )								// Local message?
			{
			debug("Deleting '%s'", fn );
			chmod( fn, 0666 );						// --> R/W mode
			unlink( fn );							// Kill � �p��� 䥭�
			}
		}

	return was_an_error ? Err : Ok;					// ����쪨...
	}



static bool
extract_name( char *name, char *names ) {
	char	*beg = names;							// Start of string
	char	nbuf[50], *np;

	while( isspace( *names ) )						// Skip spaces
		names++;

	if( *names == '\0' )							// No more names?
		return No;									// Done

	np = nbuf;
	while( *names && !isspace( *names ) )			// Get one
		*np++ = *names++;

	*np = '\0';

	strcpy( beg, names );							// Move rest of string
	strcpy( name, nbuf );						// Full name

	return Yes;
	}



static bool
find_file_to_encode( char *found_fn, int ffn_len, char *fn )
	{
	char	abs[85], drv[5], dir[70], name[15], ext[5];
	char	*p;

	fnsplit( fn, NULL, NULL, name, ext );

	fnsplit( conf.netfile_dir, drv, dir, NULL, NULL );
	fnmerge( abs, drv, dir, name, ext );

	if( access( abs, 04 ) == 0 )
		{
		strncpy( found_fn, abs, ffn_len );
		return Ok;
		}

	const		blen = 300;
	char		buf[blen+1];

	strncpy( buf, conf.infile_dirs, blen );
	buf[blen-1] = '\0';

	for(
			p = strtok( buf, "," );
			p;
			p = strtok( NULL, "," )
			)
		{

		fnsplit( p, drv, dir, NULL, NULL );
		fnmerge( abs, drv, dir, name, ext );

		if( access( abs, 04 ) == 0 )
			{
			strncpy( found_fn, abs, ffn_len );
			return Ok;
			}
		}

	return Err;
	}










