/************************ UUCP to FIDO convertor ***************************\
 *
 *      Copyright (C) 1991-1993 by Infinity Soft
 *
 *      Module  :       Header
 *
 *      $Log: hl_Bag.h $
 *      Revision 1.2  1995/11/02 14:25:20  dz
 *      Before switching to rfc_msg
 *
 *      Revision 1.1  1995/08/14 02:59:23  dz
 *      Initial revision
 *
 *
 *      
 *
 *
\*/

#ifndef HL_BAG
#define HL_BAG


#if 0
#include <ibagsls.h>
#include <hl.h>


typedef IBagOnSortedLinkedSequence<hl>      hl_Bag;
typedef hl_Bag::Cursor                      hl_BagIterator;

#endif


#endif
