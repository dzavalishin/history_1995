/************************ FIDO2UU ***************************\
 *
 *  Copyright (C) 1991-1993 by Infinity Soft
 *
 *	Module 	:	RFC Message Class: Loading
 *
 *      $Log: RFC_Msg.c $
 *
 *
 *
\*/

#include	"hl.h"
#include	"RFC_Msg.h"

bool     
load( FILE *fp )
    {
    }


