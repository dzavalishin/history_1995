head	1.2;
access;
symbols;
locks;
comment	@ * @;


1.2
date	95.11.02.14.25.20;	author dz;	state Exp;
branches;
next	1.1;

1.1
date	95.08.14.02.59.23;	author dz;	state Exp;
branches;
next	;


desc
@@


1.2
log
@Before switching to rfc_msg
@
text
@/************************ UUCP to FIDO convertor ***************************\
 *
 *      Copyright (C) 1991-1993 by Infinity Soft
 *
 *      Module  :       Header
 *
 *      $Log: hl_Bag.h $
 *      Revision 1.1  1995/08/14 02:59:23  dz
 *      Initial revision
 *
 *
 *      
 *
 *
\*/

#ifndef HL_BAG
#define HL_BAG


#if 0
#include <ibagsls.h>
#include <hl.h>


typedef IBagOnSortedLinkedSequence<hl>      hl_Bag;
typedef hl_Bag::Cursor                      hl_BagIterator;

#endif


#endif
@


1.1
log
@Initial revision
@
text
@d7 4
a10 1
 *      $Log: CC_Bag.h $
d20 2
d29 1
a29 1

@
