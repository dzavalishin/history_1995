#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rsalib.h"
#include "crc32.h"
#include "mykey.h"

static  unit    n[ MAX_UNIT_PRECISION ] = { KEY_PUBLIC_N } ;
static  unit    e[ MAX_UNIT_PRECISION ] = { KEY_PUBLIC_E } ;

static  unit    d[ MAX_UNIT_PRECISION ] = { KEY_SECRET_D } ;
static  unit    p[ MAX_UNIT_PRECISION ] = { KEY_SECRET_P } ;
static  unit    q[ MAX_UNIT_PRECISION ] = { KEY_SECRET_Q } ;
static  unit    u[ MAX_UNIT_PRECISION ] = { KEY_SECRET_U } ;

static  KEY_STRUCT      plain ;
static  unsigned char   cypher[ MAX_BYTE_PRECISION ] ;
static  KEY_STRUCT      verify ;

static  char            hex_out = 0 ;

#if sizeof plain % 2 != 0
#error Assumption on sizeof(KEY_STRUCT) failed!
#endif

static void
print_key( unsigned *p, unsigned size )
{
    int         column ;
    int         i ;
    unsigned    temp ;

for( column = 0 ; size > 0 ; size--, p++ )
    for( i = 0, temp = *p ; i < ASCII_WORD_CHARS ; i++, temp /= ASCII_CODE_COUNT ){
        putchar( ASCII_CODE_TABLE[ temp % ASCII_CODE_COUNT ] ) ;
        if( ++column == 48 ){
            putchar( '\n' ) ;
            column = 0 ;
            }
        }
if( column != 0 )
    putchar( '\n' ) ;
}

static void
print_c_key( unsigned char *data, unsigned count )
{
    int     column ;

for( column = 0 ; count > 0 ; count--, data++ ){
    printf( "0x%02x, ", *data ) ;
    column += 6 ;
    if( column >= 72 ){
        putchar( '\n' ) ;
        column = 0 ;
        }
    }
if( column != 0 )
    putchar( '\n' ) ;
}

int cdecl
main( int argc, char **argv )
{
if( argc != 3 && argc != 4 ){
    fprintf( stderr, "Type: %s [-x] Nodes \"User ID\"\n", argv[0] ) ;
    return -1 ;
    }
if( argc == 4 )
    if( stricmp( argv[1], "-x" ) != 0 ){
        fprintf( stderr, "Expecting switch!\n" ) ;
        return -1 ;
        }
    else {
        argc-- ; argv++ ;
        hex_out = 1 ;
        }
if( ( plain.nodes = atoi( argv[ 1 ] ) ) == 0 ){
    fprintf( stderr, "Zero-nodes license? Are you jocking?\n" ) ;
    return -1 ;
    }
if( strlen( argv[ 2 ] ) >= sizeof( plain.owner ) ){
    fprintf( stderr, "Registration string too long" ) ;
    return -1 ;
    }
strcpy( plain.owner, argv[ 2 ] ) ;
plain.crc = CRC_buf( (void *)&plain.nodes, sizeof( KEY_STRUCT ) - sizeof( CRC_32 ) ) ;

if( set_precision( ( KEYBITS + UNITSIZE - 1 ) / UNITSIZE ) != 0 ){
    fprintf( stderr, "\7Precision is outside of valid range !\n" ) ;
    return -1 ;
    }
fprintf( stderr, "Starting RSA secret key encryption - this may take a while!\n" ) ;
if( rsa_decrypt( (unitptr)cypher, (unitptr)&plain, d, p, q, u ) != 0 ){
    fprintf( stderr, "\7rsa_decrypt failed !" ) ;
    return -1 ;
    }
fprintf( stderr, "Verifying generated key\n" ) ;
if( mp_modexp( (unitptr)&verify, (unitptr) cypher, e, n ) != 0 ){
    fprintf( stderr, "\7mp_modexp failed !" ) ;
    return -1 ;
    }
if( memcmp( &plain, &verify, sizeof plain ) != 0 ){
    fprintf( stderr, "\7Decryption result don't match original key !\n" ) ;
    return -1 ;
    }
fprintf( stderr, "%d nodes key for \"%s\" generated\n", verify.nodes, verify.owner ) ;
if( hex_out )
     print_c_key( (unsigned char *)cypher, sizeof plain ) ;
else print_key( (unsigned *)cypher, sizeof plain / 2 ) ;
return 0 ;
}
