....

printf( "NBA " VERSION " (C) 1992 Serge Pachkovsky\n" ) ;
if( set_precision( ( KEYBITS + UNITSIZE - 1 ) / UNITSIZE ) != 0 ||
    mp_modexp( (unitptr)&plain_key, (unitptr) cypher_key, public_e, public_n ) != 0 )
        return -1 ;

....
