void recode(
	FILE *ff,		// Source file
	FILE *ft,		// Destination file
	unsigned short *tf,	// Source encoding table (language)
	unsigned short *tt	// Dest. encoding table (language)
	)
{
	register short i;
	unsigned short c;

	while((c = fgetc(ff)) != EOF) {
		if(c < 128) {
			fputc(c,ft);
			continue;
			}
		c = tf[c-128];
		for(i=0;i<128;i++)
			if(c == tt[i]) {
				fputc(i,ft);
				break;
				}
		if(i == 128)
			fputc(' ',ft);
		}
}
